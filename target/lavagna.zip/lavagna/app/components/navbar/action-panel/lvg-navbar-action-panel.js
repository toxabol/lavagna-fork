(function () {
    'use strict';

    angular.module('lavagna.components').component('lvgNavbarActionPanel', {
        bindings: {
            login: '&'
        },
        controller: function () {},
        templateUrl: 'app/components/navbar/action-panel/lvg-navbar-action-panel.html'
    });
}());
